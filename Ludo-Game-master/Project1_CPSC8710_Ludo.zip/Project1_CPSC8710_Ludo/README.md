# Ludo-Game
this is a simple Ludo Game made by using pygame module in python
This is the three player game having only one ludo piece
this game has cool features
game is fast
soo if you find any way to make the movement slow then please share it with me

Thanks
